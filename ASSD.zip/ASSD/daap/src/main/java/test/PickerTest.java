package test;

import com.daap.ui.JFilePicker;
import com.daap.ui.JOutputFilePicker;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

public class PickerTest extends JFrame implements ActionListener {
        /*
        JFrame jFrame=new JFrame("test");
        JPanel jPanel=new JPanel();
        jFrame.add(jPanel);
        JOutputFilePicker jOutputFilePicker = new JOutputFilePicker("Android Project Folder", "Browse" );
//        jOutputFilePicker.setMode(JFilePicker.MODE_SAVE);
        jPanel.add(jOutputFilePicker);
//        System.out.println(jOutputFilePicker.getPath());
        jFrame.setVisible(true);
        jFrame.setSize(500,300);
        System.out.println("---"+jOutputFilePicker.getPath());
        */

        JButton open=null;
        public static void main(String[] args) {
            new PickerTest();
        }

        public PickerTest(){
            open=new JButton("open");
            this.add(open);
            this.setBounds(400, 200, 100, 100);
            this.setVisible(true);
            this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            open.addActionListener(this);
        }
        @Override
        public void actionPerformed(ActionEvent e) {
            // TODO Auto-generated method stub
            JFileChooser jfc=new JFileChooser();

            jfc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
            jfc.showDialog(new JLabel(), "选择");
            File file=jfc.getSelectedFile();
            System.out.println(jfc.getSelectedFile().getAbsolutePath());
        }
}
