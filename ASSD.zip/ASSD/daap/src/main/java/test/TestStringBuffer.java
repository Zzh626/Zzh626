package test;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class TestStringBuffer {


    public static void main(String[] args) {
        String regex="\\w";
        String s="\n" +
                "    public void testMethod(){\n" +
                "\t\t\n" +"test"+
                "\t}";
        StringBuffer stringBuffer=new StringBuffer(s);
        stringBuffer=new StringBuffer(stringBuffer.substring(stringBuffer.indexOf("{")+1,stringBuffer.lastIndexOf("}")));

        Pattern p = Pattern.compile(regex);
        Matcher m = p.matcher(stringBuffer.toString());
        System.out.println("find():" + m.find());
        System.out.println("stringBuffer.toString().matches(\";\"):"+stringBuffer.toString().indexOf(";"));
        System.out.println("stringBuffer.toString().matches(\";\"):"+stringBuffer.toString());
        if(m.find()&&stringBuffer.toString().indexOf(";")!=-1){//能匹配到分号和 \\w
            System.out.println("false");
        }else {
            System.out.println("===========================================");
            System.out.println(s);
            System.out.println("============================================");
            System.out.println("true");
        }
    }

}
