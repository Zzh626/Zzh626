package com.daap.engine.anti_patterns.mobile;

import com.daap.model.DetectedInstance;
import com.daap.model.LegacyClass;
import com.daap.model.LegacySystem;
import com.daap.ui.ASD;
import com.daap.util.Constants;
import com.daap.util.Helper;
import com.daap.util.ResultDocument;
import com.github.javaparser.ast.body.FieldDeclaration;

import java.util.ArrayList;

public class BitmapsCollectionDetectionEngine extends engine{
    public static String smell="BC";
    private static boolean isMIM=false;


    public static void detect() {
        init();
        ASD.writeMessage("BC:");
        ResultDocument resultDocument = new ResultDocument(Constants.A_COLLECTION_BITMAPS);
        ArrayList<DetectedInstance> detectedInstances = new ArrayList<>();
        int total = 0;
        System.out.println("======================STARTED-------------------");

        for (LegacyClass legacyClass : LegacySystem.getInstance().getAllClasses()) {
            isMIM=false;
            for (FieldDeclaration fieldDeclaration : legacyClass.getFieldDeclarations()) {
                isMIM=false;
                System.out.println("fieldDeclaration : " + fieldDeclaration.toString());
                System.out.println("fieldDeclaration : " + fieldDeclaration.getCommonType());
                if (isTypeBitmap(fieldDeclaration) && isTypeCollection(fieldDeclaration)) {
//                    ASD.writeMessage("Class: " + legacyClass.getName());
                    ASD.writeMessage("Class Name: " + legacyClass.getName()
                            + "\nPath: " + legacyClass.getPath() + "\n"
                    );
                    total++;
                    isMIM=true;
                    try {
                        CreateFile.createFile(fieldDeclaration.clone().toString(),smell,ISMIM+"",isMIM);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    ISMIM++;
                    Constants.setHmap(legacyClass.getPath(),Constants.A_COLLECTION_BITMAPS);
                    boolean exists = true;
                    for (DetectedInstance detectedInstance: detectedInstances){
                        if (detectedInstance.getName().equals(legacyClass.getName())){
                            detectedInstance.increment();
                            exists = false;
                            break;
                        }
                    }
                    if (exists){
                        detectedInstances.add(new DetectedInstance(legacyClass.getName(), legacyClass.getPath(), 1));
                    }
                }
                if (!isMIM){
                    try {
                        CreateFile.createFile(fieldDeclaration.clone().toString(),smell,NOTMIM+"",isMIM);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    NOTMIM++;

                }
            }

        }

        System.out.println("total: " + total);
        ASD.writeMessage("Total: " + total);
        ASD.detectionDone();
//        Helper.writeFile(doc, "BitMapCollection");
        System.out.println("======================FINISHED-------------------");
        int srNo = 1;
        for (DetectedInstance detectedInstance : detectedInstances) {
            Helper.writeDoc(resultDocument, detectedInstance, srNo++);
        }
        Helper.writeFile(resultDocument);

    }

    private static boolean isTypeBitmap(FieldDeclaration fieldDeclaration) {
        if (fieldDeclaration.getCommonType().toString().contains(Constants.Bitmap)) {
            return true;
        }
        return false;
    }

    private static boolean isTypeCollection(FieldDeclaration fieldDeclaration) {
        if (fieldDeclaration.getCommonType().toString().contains(Constants.List) ||
                fieldDeclaration.getCommonType().toString().contains(Constants.ArrayList) ||
                fieldDeclaration.getCommonType().toString().contains(Constants.LinkedList) ||
                fieldDeclaration.getCommonType().toString().contains(Constants.LinkedHashSet) ||
                fieldDeclaration.getCommonType().toString().contains(Constants.LinkedHashMap) ||
                fieldDeclaration.getCommonType().toString().contains(Constants.HashMap) ||
                fieldDeclaration.getCommonType().toString().contains(Constants.Map) ||
                fieldDeclaration.getCommonType().toString().contains(Constants.TreeMap) ||
                fieldDeclaration.getCommonType().toString().contains(Constants.Vector) ||
                fieldDeclaration.getCommonType().toString().contains(Constants.Hashtable) ||
                fieldDeclaration.getCommonType().toString().contains(Constants.HashSet) ||
                fieldDeclaration.getCommonType().toString().contains(Constants.Collection)
                ) {
            return true;
        }
        return false;
    }
}
