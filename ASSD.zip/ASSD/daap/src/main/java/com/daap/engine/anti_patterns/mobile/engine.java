package com.daap.engine.anti_patterns.mobile;

/**
 * @author OXT
 * @version 2.0
 * @date 2021/9/26 19:39
 */
public class engine {
    public static int ISMIM=0;
    public static int NOTMIM=0;
    public static void init(){
        ISMIM=0;
        NOTMIM=0;
    }
}
