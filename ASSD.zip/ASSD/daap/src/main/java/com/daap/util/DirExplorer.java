package com.daap.util;


import com.github.javaparser.JavaParser;
import com.github.javaparser.ParseProblemException;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;

import java.io.File;
import java.io.IOException;

public class DirExplorer {
    public interface FileHandler {
        void handle(int level, String path, File file);
        /*处理java文件
        ----
        (level, path, file) -> {
            try {
                new VoidVisitorAdapter<Object>() {
                @Override
                public void visit(ClassOrInterfaceDeclaration classDeclaration, Object javaParser ) {
                    super.visit(classDeclaration, javaParser);
                    addClass(classDeclaration, javaParser, path);
                }
            }.visit(JavaParser.parse(file) , null);
        } catch (ParseProblemException | IOException e) {
            new RuntimeException(e);
        }
        }).explore(projectDir);
        ----
        */
    }

    public interface Filter {//interface
        boolean interested(int level, String path, File file);//是否java后缀
        /*(level, path, file) -> path.endsWith(".java")*/
    }

    private FileHandler fileHandler;
    private Filter filter;

    public DirExplorer(Filter filter, FileHandler fileHandler) {
        this.filter = filter;
        this.fileHandler = fileHandler;
    }

    public void explore(File root) {
        explore(0, "", root);
    }/*03explore(projectDir)*/

    private void explore(int level, String path, File file) {//3.2/*04explore(0,"",projectDir)*/  // (0,"",progectDir)
        if (file.isDirectory()) { //"F:\laboratory\AndroidDates\a2dpvolume-master"
            for (File child : file.listFiles()) {//每个子文件都遍历

                explore(level + 1, path + "/" + child.getName(), child);/*explore()*/
                /*a2dpvolume-master有三个文件夹，九个文件*/
            }
        } else {
            if (filter.interested(level, path, file)) {//是否java后缀
                fileHandler.handle(level, path, file);//
            }
        }
    }

}
