package com.daap.arrangement;

import com.daap.ui.ASD;
import com.daap.util.Constants;

import java.util.HashMap;

public class AnalyseClass {
    public static void xchange(){
        Object bf[] = Constants.HMAP.keySet().toArray();
        String af[] = new String[bf.length];
        {//转换
            for (int i=0;i< bf.length;i++) {
                System.out.println(Constants.HMAP);
                if((bf[i].toString()).contains("/app/src/test/java/")||(bf[i].toString()).contains("/app/src/androidTest/java/")) {
                    Constants.HMAP.remove(bf[i].toString());
                    af[i]="";
                    continue;
                }
                StringBuffer sb = new StringBuffer(bf[i].toString());
                sb.delete(sb.indexOf("/app/src/main/java/"), sb.indexOf("/app/src/main/java/") + 19);
                sb.delete(sb.lastIndexOf(".java"), sb.lastIndexOf(".java") + 5);
                String sx = sb.toString().replace("/", ".");
                af[i] = sx;

            }
        }

        for(int i=0;i<bf.length;i++){
            if(Constants.HMAP.containsKey(bf[i].toString())) {
                HashMap<String, Integer> hm = Constants.HMAP.get(bf[i].toString());
                Constants.HMAP.remove(bf[i].toString());
                Constants.HMAP.put(af[i], hm);
            }
        }
    }

    public static void Analyse(){
        ASD.clearConsole();
        Object allClass[]= Constants.HMAP.keySet().toArray();
        boolean consoleISEmpty=true,allSmell;
        ASD.writeMessage("Class:");
        for(Object ac:allClass){
            allSmell=true;
            for(String s:Constants.SLIST) {
                if (!Constants.HMAP.get(ac).containsKey(s)){
                    allSmell=false;
                }
            }
            if(allSmell) {
                ASD.writeMessage(ac.toString());
                consoleISEmpty=false;
            }
        }
        if (consoleISEmpty){
            ASD.clearConsole();
            ASD.writeMessage("NO SUCH CLASS !Look at the pop-up window");
        }
    }


}
