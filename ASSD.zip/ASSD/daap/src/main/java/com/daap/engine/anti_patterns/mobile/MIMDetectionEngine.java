package com.daap.engine.anti_patterns.mobile;

import com.daap.model.DetectedInstance;
import com.daap.model.LegacyClass;
import com.daap.model.LegacySystem;
import com.daap.ui.ASD;
import com.daap.util.Constants;
import com.daap.util.Helper;
import com.daap.util.ResultDocument;
import com.github.javaparser.ast.NodeList;
import com.github.javaparser.ast.body.FieldDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.stmt.Statement;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MIMDetectionEngine {
    public static String smell="MIM";
    private static int ISMIM=0;
    private static int NOTMIM=0;
    private static boolean isMIM=false;

    private static final int DIT = 6;
    private static int total = 0;
    private static void initStaticValue(){
    }
    public static void detect() throws Exception {
        initStaticValue();
        ASD.writeMessage("M I M:\n");
        System.out.println("\n\n\n\n\nMIM:\n");
        ResultDocument resultDocument = new ResultDocument(Constants.A_MEMBER_IGNORING_METHOD);
        ArrayList<DetectedInstance> detectedInstances = new ArrayList<>();
        total = 0;  // check it.
        System.out.println("======================STARTED-------------------");

        int testFlag=1;
        for (LegacyClass legacyClass : LegacySystem.getInstance().getAllClasses()) {
            isMIM=false;
            //取出每个class
            for (MethodDeclaration methodDeclaration : legacyClass.getMethodDeclarations()) {
            //取出每个函数
                 isMIM=false;
                if (methodDeclaration.isStatic()||isNullMethod(methodDeclaration)) {
                    //排除static函数和空函数

                    CreateFile.createFile(methodDeclaration.clone().toString(),smell,NOTMIM+"",isMIM);
                    NOTMIM++;
                    break;
                }
                NodeList<Statement> fieldsAccessList = getFieldsAccessList(methodDeclaration);//

//                System.out.println("fieldsAccessList size: "+fieldsAccessList.size());
                boolean contains = false;//
                outer:
                for (FieldDeclaration fieldDeclaration : legacyClass.getFieldDeclarations()) {
//                    System.out.println("fieldDeclaration: " +fieldDeclaration.getVariable(0).getNameAsString());
                    inner:
                    for (Statement statement : fieldsAccessList) {
                        if (statement.toString().contains(fieldDeclaration.getVariable(0).getNameAsString())) {
                            contains = true;
//                            System.out.println("found ");
                            break outer;
                        }
                    }
                }

                if (!contains) {//找到了MIM
                    total++;
                    isMIM=true;
                    System.out.println("\n------MIM"+total+"\ttest:"+(testFlag++)+"------\n");
                    System.out.println("\nClass Name: " + legacyClass.getName()
                            + "\nPath: " + legacyClass.getPath() + "\n");

//                    Constants.setHmap(legacyClass.getName(),Constants.A_MEMBER_IGNORING_METHOD);
//                    Helper.writeDoc(table, legacyClass, total);
                    Constants.setHmap(legacyClass.getPath(),Constants.A_MEMBER_IGNORING_METHOD);

                    boolean exists = true;
                    for (DetectedInstance detectedInstance: detectedInstances){
                        if (detectedInstance.getName().equals(legacyClass.getName())){
                            detectedInstance.increment();
                            exists = false;
                            break;
                        }
                    }
                    if (exists){
                        detectedInstances.add(new DetectedInstance(legacyClass.getName(), legacyClass.getPath(), 1));
                    }

                    //找到MIM
                    CreateFile.createFile(methodDeclaration.clone().toString(),smell,ISMIM+"",isMIM );
                    ISMIM++;
                    System.out.println("legacyClass: " + legacyClass.getName() + " methodDeclaration: " + methodDeclaration.getNameAsString());


                    System.out.println("clone: "+methodDeclaration.clone().toString());//获得方法克隆

//                    System.out.println();
//                    System.out.println("getMetaModel: "+methodDeclaration.getMetaModel());
                    break;
                }
                if (!isMIM){
                    CreateFile.createFile(methodDeclaration.clone().toString(),smell,NOTMIM+"",isMIM);
                    NOTMIM++;

                }
            }

        }
        System.out.println("total: " + total);
        ASD.detectionDone();
        System.out.println("======================FINISHED-------------------");


        int srNo = 1;
        for (DetectedInstance detectedInstance : detectedInstances) {
            Helper.writeDoc(resultDocument, detectedInstance, srNo++);
        }

        Helper.writeFile(resultDocument);

    }

    private static boolean isNullMethod(MethodDeclaration methodDeclaration){
//        System.out.println("---------isNullMethod 调用\n");
        String regex="\\w";
        try {
            StringBuffer stringBuffer = new StringBuffer(methodDeclaration.clone().toString());
            stringBuffer = new StringBuffer(stringBuffer.substring(stringBuffer.indexOf("{") + 1, stringBuffer.lastIndexOf("}")));

            Pattern p = Pattern.compile(regex);
            Matcher m = p.matcher(stringBuffer.toString());
    //        System.out.println("find():" + m.find());
    //        System.out.println("stringBuffer.toString().matches(\";\"):"+stringBuffer.toString().indexOf(";"));
    //        System.out.println("stringBuffer.toString().matches(\";\"):"+stringBuffer.toString());
            if(m.find()&&stringBuffer.toString().indexOf(";")!=-1){
                return false;
            }else {
    //            System.out.println("===========================================");
    //            System.out.println(methodDeclaration);
    //            System.out.println("============================================");
    //            System.out.println("-------------------isNullMethod 结束 是空方法\n\n");
                return true;
            }
        }catch (Exception e){
            return true;
        }
    }




    public static int getDIT() {
        return DIT;
    }

    private static NodeList<Statement> getFieldsAccessList(MethodDeclaration methodDeclaration) {


        NodeList<Statement> statements = new NodeList<>();

        try {
            statements = methodDeclaration.getBody().get().getStatements();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return statements;

    }

}
