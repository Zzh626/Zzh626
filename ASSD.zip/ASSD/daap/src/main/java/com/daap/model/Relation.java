package com.daap.model;



public class Relation {
    public enum Type {
        calls, creates, references, uses, inherits, has, relates
    }

    protected LegacyClass from;
    protected LegacyClass to;
    protected Type type;

    public Relation(LegacyClass A, LegacyClass B, Type type) {
        from = A;
        to = B;
        this.type = type;
    }

    public LegacyClass getFrom() {
        return from;
    }

    public LegacyClass getTo() {
        return to;
    }

    public Type getType() {
        return type;
    }

    public boolean hasType(Type type) {
        return this.type == type;
    }

    public String printRelation() {
        return from.getName() + " " + type + " " + to.getName();
    }
}