package com.daap.engine.anti_patterns.mobile;

import com.daap.ui.ASD;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

/**
 * @author OXT
 * @version 2.0
 * @date 2021/9/26 16:26
 */
public class CreateFile {
    public static void createFile(String context,String smell,String filename, boolean isBad) throws Exception{
        String s= ASD.projectSrcFolder;
        String DRIVE=s.substring(0,2)+"\\AndroidAppData";
        String folderPath=DRIVE + "\\AndroidApp" /*+ FOLDER*/;
        if(isBad){
            File file = new File(folderPath+"\\"+smell);
            if (!file.exists()) {
                file.mkdirs();
            }
            try {
                String filepath = folderPath+"\\"+smell+ "\\" + filename  + ".java";
                BufferedWriter bw = new BufferedWriter(new FileWriter(filepath));
                System.out.println("-=-=-=-=-=-=-=filepath:" + filepath + "-=-=-=-=-=-=-=-=-=-=-=-=");
                bw.write(context);
                bw.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }else{
            File file = new File(folderPath+"\\NOT_"+smell);
            if (!file.exists()) {
                file.mkdirs();
            }
            try {
                String filepath = folderPath+"\\Not_"+smell + "\\" +filename + ".java";
                BufferedWriter bw = new BufferedWriter(new FileWriter(filepath));
                System.out.println("-=-=-=-=-=-=-=filepath:" + filepath + "-=-=-=-=-=-=-=-=-=-=-=-=");
                bw.write(context);
                bw.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }
}
