package com.daap.engine.anti_patterns.mobile;

import com.daap.model.DetectedInstance;
import com.daap.model.LegacyClass;
import com.daap.model.LegacySystem;
import com.daap.ui.ASD;
import com.daap.util.Constants;
import com.daap.util.Helper;
import com.daap.util.ResultDocument;
import com.github.javaparser.ast.body.FieldDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.expr.MethodCallExpr;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;

import java.util.ArrayList;

public class InternalSetGetDetectionEngine extends engine{
    public static String smell="ISG";
    private static boolean isMIM=false;
    private static int total = 0;
//    private static final String fileName = "InternalSetGet";

    public static void detect() {
        init();

        total = 0;
        ASD.writeMessage("ISG:");
        ResultDocument resultDocument = new ResultDocument(Constants.A_INTERNAL_GETTER_SETTER);
        ArrayList<DetectedInstance> detectedInstances = new ArrayList<>();
        System.out.println("======================STARTED-------------------");



//        outer:
        for (LegacyClass legacyClass : LegacySystem.getInstance().getAllClasses()) {
            isMIM=false;
            for (MethodDeclaration methodDeclaration : legacyClass.getMethodDeclarations()) {
                isMIM=false;
                for (MethodCallExpr methodCallExpr : getMethodCalls(methodDeclaration)) {

                    if (isGetterSetterMethod(methodCallExpr, legacyClass)) {
                        if (isInternalMethod(methodCallExpr, legacyClass)) {
                            System.out.println("legacyClass: " + legacyClass.getName() + " methodCallExpr: " + methodCallExpr.getNameAsString());
                            total++;
//                            ASD.writeMessage("Class: " + legacyClass.getName());
                            ASD.writeMessage("Class Name: " + legacyClass.getName()
                                    + "\nPath: " + legacyClass.getPath() + "\n"
                            );
                            try {
                                isMIM=true;
                                CreateFile.createFile(methodDeclaration.clone().toString(),smell,ISMIM+"",isMIM);
                                ISMIM++;
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
//                            Constants.setHmap(legacyClass.getName(),Constants.A_INTERNAL_GETTER_SETTER);
//                            Helper.writeDoc(table, legacyClass, total);
                            Constants.setHmap(legacyClass.getPath(),Constants.A_INTERNAL_GETTER_SETTER);
                            boolean exists = true;
                            for (DetectedInstance detectedInstance: detectedInstances){
                                if (detectedInstance.getName().equals(legacyClass.getName())){
                                    detectedInstance.increment();
                                    exists = false;
                                    break;
                                }
                            }
                            if (exists){
                                detectedInstances.add(new DetectedInstance(legacyClass.getName(), legacyClass.getPath(), 1));
                            }

//                            continue outer;
                        }
                    }
                }
                if (!isMIM){
                    try {
                        CreateFile.createFile(methodDeclaration.clone().toString(),smell,NOTMIM+"",isMIM);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    NOTMIM++;
                }
            }
        }

        System.out.println("total: " + total);
        ASD.writeMessage("Total: " + total);
        ASD.detectionDone();

//        Helper.writeFile(doc, "InternalSetGet");
        System.out.println("======================FINISHED-------------------");

        int srNo = 1;
        for (DetectedInstance detectedInstance : detectedInstances) {
            Helper.writeDoc(resultDocument, detectedInstance, srNo++);
        }
        Helper.writeFile(resultDocument);

    }

    private static ArrayList<MethodCallExpr> getMethodCalls(MethodDeclaration methodDeclaration) {
        ArrayList<MethodCallExpr> methodCallExprs = new ArrayList<>();
        methodDeclaration.accept(new VoidVisitorAdapter<Object>() {
            @Override
            public void visit(MethodCallExpr methodCallExpr, Object javaParserFacade) {
                super.visit(methodCallExpr, javaParserFacade);
                methodCallExprs.add(methodCallExpr);
            }
        }, null);
        return methodCallExprs;
    }

    private static boolean isGetterSetterMethod(MethodCallExpr methodDeclaration, LegacyClass legacyClass) {
        for (FieldDeclaration var : legacyClass.getFieldDeclarations()) {
            if (methodDeclaration.getNameAsString().toLowerCase().equals("get" + var.getVariables().get(0).getNameAsString())) {
                return true;
            } else if (methodDeclaration.getNameAsString().toLowerCase().equals("set" + var.getVariables().get(0).getNameAsString())) {
                return true;
            }
        }
        return false;
    }

    private static boolean isInternalMethod(MethodCallExpr methodCallExpr, LegacyClass legacyClass) {
        for (MethodDeclaration method : legacyClass.getMethodDeclarations()) {
            if (methodCallExpr.getName().equals(method.getName())) {
                return true;
            }
        }
        return false;
    }
}
